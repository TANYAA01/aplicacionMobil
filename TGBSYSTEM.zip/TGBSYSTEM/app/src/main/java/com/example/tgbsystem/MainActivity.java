package com.example.tgbsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etName, psw1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        psw1 = findViewById(R.id.psw1);

        Button btnLog = findViewById(R.id.btnLog);

        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = etName.getText().toString().trim();
                String pass = psw1.getText().toString().trim();
                if (psw1.length() == 0) {
                    Toast notificacion = Toast.makeText(MainActivity.this, "La clave ingresada no puede quedar vacía", Toast.LENGTH_LONG);
                    notificacion.show();
                } else if (user.equals("admin") && pass.equals("12345")) {
                    Toast notificacion = Toast.makeText(MainActivity.this, "Clave y Usuario ingresados correctamente", Toast.LENGTH_LONG);
                    notificacion.show();
                    Intent i = new Intent(MainActivity.this, administracion.class);
                    i.putExtra("usuario", user);
                    i.putExtra("cedula", pass);

                    startActivity(i);
                }else if (user.equals("user") && pass.equals("123")) {
                    Toast notificacion = Toast.makeText(MainActivity.this, "Clave y Usuario ingresados correctamente", Toast.LENGTH_LONG);
                    notificacion.show();
                    Intent i = new Intent(MainActivity.this, usuarios.class);
                    i.putExtra("user", user);
                    i.putExtra("12345", pass);

                    startActivity(i);
                }else {
                    Toast notificacion = Toast.makeText(MainActivity.this, "Clave o Usuario incorrectos", Toast.LENGTH_LONG);
                    notificacion.show();
                }



            }
        });
    }
}