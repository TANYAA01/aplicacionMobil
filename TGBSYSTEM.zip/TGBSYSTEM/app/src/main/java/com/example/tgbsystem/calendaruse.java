package com.example.tgbsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class calendaruse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendaruse);
    }
}