package com.example.tgbsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class comunicadoadm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comunicadoadm);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent intent;

        switch (id) {
            case R.id.op1:
                intent = new Intent(this, eventoadm.class);
                startActivity(intent);
                return true;
            case R.id.op2:
                intent = new Intent(this, comunicadoadm.class);
                startActivity(intent);
                return true;
            case R.id.op3:
                intent = new Intent(this, foro.class);
                startActivity(intent);
                return true;
            case R.id.op4:
                intent = new Intent(this, calendaradm.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}