package com.example.tgbsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class eventoadm extends AppCompatActivity {
    private Spinner spinner1;
    private EditText punto,henc,lugar,fechevt,horaevt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventoadm);


        spinner1 = (Spinner) findViewById(R.id.spnPais);
        String []opciones={"Minga","Reunion","Ferias Locales","Limpieza Parque", "Otro tema"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, opciones);
        spinner1.setAdapter(adapter);
        punto=(EditText)findViewById(R.id.pen);
        henc=(EditText)findViewById(R.id.hen);
        lugar=(EditText)findViewById(R.id.lev);
        fechevt=(EditText)findViewById(R.id.fev);
        horaevt=(EditText)findViewById(R.id.hev);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent intent;

        switch (id) {
            case R.id.op1:
                intent = new Intent(this, eventoadm.class);
                startActivity(intent);
                return true;
            case R.id.op2:
                intent = new Intent(this, comunicadoadm.class);
                startActivity(intent);
                return true;
            case R.id.op3:
                intent = new Intent(this, foro.class);
                startActivity(intent);
                return true;

            case R.id.op5:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void guardar(View v) {
        // Obtener los valores de los campos
        String evt = spinner1.getSelectedItem().toString(); // Obtener el valor seleccionado en el Spinner
        String punenc = punto.getText().toString().trim();
        String horenc = henc.getText().toString().trim();
        String lugevt = lugar.getText().toString().trim();
        String fecevt = fechevt.getText().toString().trim();
        String horevt = horaevt.getText().toString().trim();
        // Abrir la base de datos
        sqLiteHelp admin = new sqLiteHelp(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        ContentValues registro = new ContentValues();
        registro.put("evento", evt);
        registro.put("puntoencuentro", punenc);
        registro.put("horaencuentro", horenc);
        registro.put("lugarevento", lugevt);
        registro.put("fechaevento", fecevt);
        registro.put("horaevento", horevt);

        // Insertar el registro en la tabla 'personas'
        bd.insert("eventos", null, registro);
        bd.close();

        // Limpiar los campos después de guardar el registro
        punto.setText("");
        henc.setText("");
        lugar.setText("");
        fechevt.setText("");

        Toast.makeText(this, "Se cargaron los datos del evento", Toast.LENGTH_SHORT).show();
    }

    public void buscar(View v) {
        String evt = spinner1.getSelectedItem().toString();
        String punenc = punto.getText().toString().trim();
        String horenc = henc.getText().toString().trim();
        String lugevt = lugar.getText().toString().trim();
        String fecevt = fechevt.getText().toString().trim();
        String horevt = horaevt.getText().toString().trim();

        sqLiteHelp admin = new sqLiteHelp(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        ContentValues registro = new ContentValues();
        registro.put("evento", evt);
        registro.put("puntoencuentro", punenc);
        registro.put("horaencuentro", horenc);
        registro.put("lugarevento", lugevt);
        registro.put("fechaevento", fecevt);
        registro.put("horaevento", horevt);

        bd.insert("eventos", null, registro);

        Cursor cursor = bd.rawQuery("SELECT * FROM eventos ORDER BY id DESC LIMIT 1", null);
        if (cursor != null && cursor.moveToFirst()) {
            String ultimoEvt = cursor.getString(1);
            String ultimoPunenc = cursor.getString(2);
            String ultimoHorenc = cursor.getString(3);
            String ultimoLugevt = cursor.getString(4);
            String ultimoFecevt = cursor.getString(5);
            String ultimoHorevt = cursor.getString(6);

            spinner1.setSelection(obtenerIndiceSpinner(spinner1, ultimoEvt));
            punto.setText(ultimoPunenc);
            henc.setText(ultimoHorenc);
            lugar.setText(ultimoLugevt);
            fechevt.setText(ultimoFecevt);
            horaevt.setText(ultimoHorevt);
        }

        if (cursor != null) {
            cursor.close();
        }
        bd.close();

        Toast.makeText(this, "Se cargaron los datos del evento", Toast.LENGTH_SHORT).show();
    }

    private int obtenerIndiceSpinner(Spinner spinner, String valor) {
        int index = 0;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equals(valor)) {
                index = i;
                break;
            }
        }
        return index;
    }



}