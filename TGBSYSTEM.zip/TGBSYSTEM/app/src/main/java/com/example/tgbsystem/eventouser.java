package com.example.tgbsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class eventouser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventouser);

        // Enlaza los TextViews del layout XML
        TextView textViewPuntoEncuentro = findViewById(R.id.textViewPuntoEncuentro);
        TextView textViewHoraEncuentro = findViewById(R.id.textViewHoraEncuentro);
        TextView textViewLugarEvento = findViewById(R.id.textViewLugarEvento);
        TextView textViewFechaEvento = findViewById(R.id.textViewFechaEvento);
        TextView textViewHoraEvento = findViewById(R.id.textViewHoraEvento);

        // Realiza la consulta para obtener el último evento registrado
        sqLiteHelp admin = new sqLiteHelp(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        Cursor cursor;
        cursor = bd.rawQuery("SELECT * FROM eventos ORDER BY id DESC LIMIT 1", null);

        if (cursor != null && cursor.moveToFirst()) {
            // Obtén los datos del evento más reciente
            String puntoEncuentro = cursor.getString(cursor.getColumnIndex("puntoencuentro"));
            String horaEncuentro = cursor.getString(cursor.getColumnIndex("horaenceuntro"));
            String lugarEvento = cursor.getString(cursor.getColumnIndex("lugarevento"));
            String fechaEvento = cursor.getString(cursor.getColumnIndex("fechaevento"));
            String horaEvento = cursor.getString(cursor.getColumnIndex("hora_evento"));

            // Muestra los datos en los TextView correspondientes
            textViewPuntoEncuentro.setText(puntoEncuentro);
            textViewHoraEncuentro.setText(horaEncuentro);
            textViewLugarEvento.setText(lugarEvento);
            textViewFechaEvento.setText(fechaEvento);
            textViewHoraEvento.setText(horaEvento);
        } else {
            // Si no se encontró ningún evento registrado
            Toast.makeText(this, "No hay eventos registrados", Toast.LENGTH_SHORT).show();
        }

        // Cierra el cursor y la conexión a la base de datos
        if (cursor != null) {
            cursor.close();
        }
        bd.close();
    }

    }




