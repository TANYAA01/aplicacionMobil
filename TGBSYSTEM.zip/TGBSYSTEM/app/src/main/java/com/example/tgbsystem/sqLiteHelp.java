package com.example.tgbsystem;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class sqLiteHelp extends SQLiteOpenHelper {
    public sqLiteHelp(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

       //TABLA EVENTOS
        //String tevento= "CREATE TABLE eventos (id INTEGER PRIMARY KEY AUTOINCREMENT, evento TEXT, puntoencuentro TEXT, horaencuentro TEXT, lugarevento TEXT, fechaevento TEXT, horaevento TEXT)";

        // Crear la tabla para comunicados
       // String tcomunicados = "CREATE TABLE comunicados (idcom INTEGER PRIMARY KEY AUTOINCREMENT, comunicado TEXT)";

        // Crear la tabla para el foro
        //String tforo = "CREATE TABLE foro (idmsj INTEGER PRIMARY KEY AUTOINCREMENT, mensaje TEXT)";

        // Ejecutar las consultas SQL para crear las tablas
        db.execSQL("CREATE TABLE eventos (id INTEGER PRIMARY KEY AUTOINCREMENT, evento TEXT, puntoencuentro TEXT, horaencuentro TEXT, lugarevento TEXT, fechaevento TEXT, horaevento TEXT)");
        //db.execSQL(tcomunicados);
        //db.execSQL(tforo);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
